(function($) {
  'use strict';
  var clipboard = new ClipboardJS('.btn-clipboard');
})(jQuery);
