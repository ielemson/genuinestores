<?= $this->extend('admin/layouts/app'); ?>

<!-- MAIN CONTENT -->
<?= $this->section('content'); ?>

<?= $this->include('admin/common/dashboard'); ?>

<?= $this->endSection(); ?>

