<?= $this->extend('layouts/common/main'); ?>

<?= $this->section('content'); ?>

<?= $this->include('common/pages/login'); ?>

<?= $this->endSection(); ?>